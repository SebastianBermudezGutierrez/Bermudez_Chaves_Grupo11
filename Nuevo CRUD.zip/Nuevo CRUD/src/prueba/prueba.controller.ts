import { Controller, Get, Post, Body, Patch, Param, Delete, ParseIntPipe } from '@nestjs/common';
import { PruebaService } from './prueba.service';
import { CreatePruebaDto } from './dto/create-Prueba.dto';

@Controller('prueba')
export class PruebaController {
    constructor(private readonly pruebaService: PruebaService) {}

    @Get()
    getAllPrueba(){
        return this.pruebaService.findAll()
    }

    @Get('id/:id')
    getCarById(@Param('id', ParseUUIDPipe)id:string){
        console.log({id})
        return this.pruebaService.findOneById(id);
    }

    @Get('titulo/:titulo')
    getCarByTitulo(@Param('titulo')titulo){
        console.log({titulo})
        return this.pruebaService.findOneByTitulo(titulo);
    }


    @Post()
    createPrueba(@Body() createPruebaDto:CreatePruebaDto){
        return this.pruebaService.create(createPruebaDto);
    }

    @Patch('id/:id')
    updatePrueba(
        @Param('id', ParseIntPipe) id:number,
        @Body() body:any){
        return body;
    }

    @Delete('id/:id')
    deletePrueba(@Param('id', ParseIntPipe) id:number){
        return{
            method:'delete',
            id
        }
    } 
}
