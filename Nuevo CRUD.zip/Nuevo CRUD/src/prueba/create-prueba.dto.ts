import { IsString, MinLength } from "class-validator";

export class CreatePruebaDto{
    
    readonly id: number;
    readonly titulo: string;
    readonly autor: string;
    readonly año_publicacion: number;
    readonly genero: string;
    readonly editorial: string;
    readonly idioma: string;
    readonly paginas: number;
}